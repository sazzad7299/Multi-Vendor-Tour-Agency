<?php $__env->startSection('content'); ?>

    <section class="go-section">
        <div class="row">
            <div class="container">
                <div class="col-md-offset-2 col-md-8">
                    <?php if(Session::has('error')): ?>
                        <div class="alert alert-danger alert-dismissable">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <?php echo e(Session::get('error')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="col-md-12 text-center services">
                    <div class="col-md-12 order-div">

                        <div class="col-md-7 order-left">
                            <h4>ENTER SHIPPING DETAILS</h4>
                            <form class="col-md-offset-2 col-md-8" action="<?php echo e(route('payment.submit')); ?>" method="post" id="payment_form">
                                <?php echo e(csrf_field()); ?>


                                <div class="form-group">
                                    <input type="text" class="form-control" name="name" value="<?php echo e(Auth()->user()->name); ?>" placeholder="Full Name" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" name="phone" value="<?php echo e(Auth()->user()->phone); ?>" placeholder="Phone Number" required>
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control" name="email" value="<?php echo e(Auth()->user()->email); ?>" placeholder="Email" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" name="address" value="<?php echo e(Auth()->user()->address); ?>" placeholder="Address" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" name="city" value="<?php echo e(Auth()->user()->city); ?>" placeholder="City" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" name="zip" value="<?php echo e(Auth()->user()->zip); ?>" placeholder="Postal Code" required>
                                </div>
                                <div class="form-group">
                                    <select class="form-control" onChange="meThods(this)" id="formac" name="method" required>
                                        <option value="Paypal" selected>Paypal</option>
                                        <option value="Stripe">Credit Card</option>
                                        <option value="Cash">Cash On Delivery</option>
                                    </select>
                                </div>
                                <div id="stripes" style="display: none;">
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="card" placeholder="Card">
                                    </div>
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="cvv" placeholder="Cvv">
                                    </div>
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="month" placeholder="Month">
                                    </div>
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="year" placeholder="Year">
                                    </div>
                                </div>

                                <input type="hidden" name="total" value="<?php echo e($total); ?>" />
                                <input type="hidden" name="products" value="<?php echo e($product); ?>" />
                                <input type="hidden" name="quantities" value="<?php echo e($quantity); ?>" />
                                <input type="hidden" name="customer" value="<?php echo e(Auth()->user()->id); ?>" />

                                <div id="paypals">
                                    <input type="hidden" name="cmd" value="_xclick" />
                                    <input type="hidden" name="no_note" value="1" />
                                    <input type="hidden" name="lc" value="UK" />
                                    <input type="hidden" name="currency_code" value="USD" />
                                    <input type="hidden" name="bn" value="PP-BuyNowBF:btn_buynow_LG.gif:NonHostedGuest" />
                                </div>
                                <button type="submit" class="button style-10"></i> Pay Now</button>
                            </form>

                        </div>
                        <div class="col-md-5 order-right">
                            <h4>ORDER DETAILS</h4>
                            <h3 class="pricing-count" style="margin: 0">Total Cost: $<?php echo e($total); ?></h3><hr>
                            <div class="pricing-list">
                                <table class="table">
                                    <thead>
                                    <tr>
                                        <th>Product</th>
                                        <th width="20%">Quantity</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $cartdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($cart->title); ?></td>
                                        <td><?php echo e($cart->quantity); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <script type="text/javascript">
        function meThods(val) {
            var action1 = "<?php echo e(route('payment.submit')); ?>";
            var action2 = "<?php echo e(route('stripe.submit')); ?>";
            var action3 = "<?php echo e(route('cash.submit')); ?>";
            if (val.value == "Paypal") {
                $("#payment_form").attr("action", action1);
                $("#stripes").hide();
            }
            if (val.value == "Stripe") {
                $("#payment_form").attr("action", action2);
                $("#stripes").show();
            }
            if (val.value == "Cash") {
                $("#payment_form").attr("action", action3);
                $("#stripes").hide();
            }
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>