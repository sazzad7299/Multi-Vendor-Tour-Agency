<?php $__env->startSection('content'); ?>


    <section style="background: url(<?php echo e(url('/')); ?>/assets/images/<?php echo e($settings[0]->background); ?>) no-repeat center center; background-size: cover;">
        <div class="row" style="background-color:rgba(0,0,0,0.7);">

            <div style="margin: 3% 0px 3% 0px;">
                <div class="text-center" style="color: #FFF;padding: 20px;">
                    <h1><?php echo e($language->search_result); ?>: <?php echo e($tag); ?></h1>
                </div>
            </div>

        </div>


    </section>



    <div class="section-padding product-filter-wrapper wow fadeInUp">
            <div class="container">
                <div class="row">
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                            <div class="single-product-carousel-item text-center">
                                <a href="<?php echo e(url('/product')); ?>/<?php echo e($product->id); ?>/<?php echo e(str_replace(' ','-',strtolower($product->title))); ?>"> <img src="<?php echo e(url('/assets/images/products')); ?>/<?php echo e($product->feature_image); ?>" alt="Product Image" /> </a>
                                <div class="product-carousel-text">
                                    <a href="<?php echo e(url('/product')); ?>/<?php echo e($product->id); ?>/<?php echo e(str_replace(' ','-',strtolower($product->title))); ?>">
                                        <h4 class="product-title"><?php echo e($product->title); ?></h4>
                                    </a>
                                    <div class="product-review">
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <div class="product-price">
                                        <?php if($product->previous_price != ""): ?>
                                            <span class="original-price">$<?php echo e(\App\Product::Cost($product->id)); ?></span>
                                        <?php else: ?>
                                        <?php endif; ?>
                                        <del class="offer-price">$<?php echo e($product->previous_price); ?></del>
                                    </div>
                                    <div class="product-meta-area">
                                        <form class="addtocart-form">
                                            <?php echo e(csrf_field()); ?>

                                            <?php if(Session::has('uniqueid')): ?>
                                                <input type="hidden" name="uniqueid" value="<?php echo e(Session::get('uniqueid')); ?>">
                                            <?php else: ?>
                                                <input type="hidden" name="uniqueid" value="<?php echo e(str_random(7)); ?>">
                                            <?php endif; ?>
                                            <input type="hidden" name="title" value="<?php echo e($product->title); ?>">
                                            <input type="hidden" name="product" value="<?php echo e($product->id); ?>">
                                            <input type="hidden" id="cost" name="cost" value="<?php echo e(\App\Product::Cost($product->id)); ?>">
                                            <input type="hidden" id="quantity" name="quantity" value="1">
                                            <?php if($product->stock != 0 || $product->stock === null ): ?>
                                                <button type="button" class="addTo-cart to-cart"><i class="fa fa-cart-plus"></i><span><?php echo e($language->add_to_cart); ?></span></button>
                                            <?php else: ?>
                                                <button type="button" class="addTo-cart  to-cart" disabled><i class="fa fa-cart-plus"></i><?php echo e($language->out_of_stock); ?></button>
                                            <?php endif; ?>
                                        </form>
                                        <a  href="javascript:;" class="wish-list" onclick="getQuickView(<?php echo e($product->id); ?>)" data-toggle="modal" data-target="#myModal">
                                            <i class="fa fa-eye"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <h3><?php echo e($language->no_result); ?></h3>
                    <?php endif; ?>
                </div>
            </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.newmaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>