

<?php $__env->startSection('content'); ?>

    <div id="page-wrapper">
        <div class="container-fluid">
            <div class="row" id="main">
                <!-- Page Heading -->
                <div class="go-title">
                    <div class="pull-right">
                        <span><span style="background-color: lightgreen;">&nbsp;&nbsp;&nbsp;&nbsp;</span> Completed</span>
                        <span><span style="background-color: #d9edf7;">&nbsp;&nbsp;&nbsp;&nbsp;</span> Processing</span>
                    </div>
                    <h3>Orders</h3>
                    <div class="go-line"></div>
                </div>
                <!-- Page Content -->
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div id="response">
                            <?php if(Session::has('message')): ?>
                                <div class="alert alert-success alert-dismissable">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <?php echo e(Session::get('message')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                        <table class="table table-striped table-bordered" cellspacing="0" id="example" width="100%">
                            <thead>
                            <tr>
                                <th>Customer Email</th>
                                <th width="15%">Customer Name</th>
                                <th width="5%">Total Product</th>
                                <th width="10%">Total Cost</th>
                                <th>Payment Method</th>
                                <th>Actions</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($order->status == "completed"): ?>
                                    <tr style="background-color: lightgreen;">
                                <?php elseif($order->status == "processing"): ?>
                                    <tr class="info">
                                <?php else: ?>
                                    <tr class="">
                                <?php endif; ?>
                                    <td><?php echo e($order->customer_email); ?></td>
                                    <td><?php echo e($order->customer_name); ?></td>
                                    <td><?php echo e(array_sum($order->quantities)); ?></td>
                                    <td>$<?php echo $order->pay_amount; ?></td>
                                    <td><?php echo e($order->method); ?></td>

                                    <td>

                                        <a href="orders/<?php echo e($order->id); ?>" class="btn btn-primary btn-xs"><i class="fa fa-check"></i> View Details </a>

                                        <a href="orders/email/<?php echo e($order->id); ?>" class="btn btn-primary btn-xs"><i class="fa fa-send"></i> Send Email</a>

                                        ​<span class="dropdown">
                                            <button class="btn btn-primary dropdown-toggle btn-xs" type="button" data-toggle="dropdown"><?php echo e(ucfirst($order->status)); ?>

                                                <span class="caret"></span></button>
                                            <ul class="dropdown-menu">
                                                <li><a href="orders/status/<?php echo e($order->id); ?>/processing">Processing</a></li>
                                                <li><a href="orders/status/<?php echo e($order->id); ?>/completed">Completed</a></li>
                                            </ul>
                                        </span>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- /#page-wrapper -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.includes.master-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>