<?php $__env->startSection('content'); ?>

    <div class="home-wrapper">

        
        <?php if($pagesettings[0]->slider_status): ?>
        <section class="go-slider">
            <div id="bootstrap-touch-slider" class="carousel bs-slider fade  control-round indicators-line" data-ride="carousel" data-pause="hover" data-interval="5000" >

            <!-- Wrapper For Slides -->
                <div class="carousel-inner" role="listbox">

                <?php for($i = 0; $i < count($sliders); $i++): ?>
                    <?php if($i == 0): ?>
                        <!-- Third Slide -->
                            <div class="item active">

                                <!-- Slide Background -->
                                <img src="<?php echo e(url('/')); ?>/assets/images/sliders/large/<?php echo e($sliders[$i]->image); ?>" alt="Bootstrap Touch Slider"  class="slide-image"/>
                                <div class="bs-slider-overlay"></div>

                                <div class="container">
                                    <div class="row">
                                        <!-- Slide Text Layer -->
                                        <div class="slide-text <?php echo e($sliders[$i]->text_position); ?>">

                                            <h1 data-animation="animated fadeInDown"><?php echo e($sliders[$i]->title); ?></h1>
                                            <p data-animation="animated fadeInUp"><?php echo e($sliders[$i]->text); ?></p>

                                        </div>

                                    </div>
                                </div>
                            </div>
                            <!-- End of Slide -->
                    <?php else: ?>
                        <!-- Second Slide -->
                            <div class="item">

                                <!-- Slide Background -->
                                <img src="<?php echo e(url('/')); ?>/assets/images/sliders/large/<?php echo e($sliders[$i]->image); ?>" alt="Bootstrap Touch Slider"  class="slide-image"/>
                                <div class="bs-slider-overlay"></div>
                                <!-- Slide Text Layer -->
                                <div class="slide-text <?php echo e($sliders[$i]->text_position); ?>">
                                    <h1 data-animation="animated fadeInDown"><?php echo e($sliders[$i]->title); ?></h1>
                                    <p data-animation="animated fadeInUp"><?php echo e($sliders[$i]->text); ?></p>
                                </div>
                            </div>
                            <!-- End of Slide -->
                        <?php endif; ?>
                    <?php endfor; ?>

                </div><!-- End of Wrapper For Slides -->

                <!-- Left Control -->
                <a class="left carousel-control" href="#bootstrap-touch-slider" role="button" data-slide="prev">
                    <span class="fa fa-angle-left" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>

                <!-- Right Control -->
                <a class="right carousel-control" href="#bootstrap-touch-slider" role="button" data-slide="next">
                    <span class="fa fa-angle-right" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>

            </div> <!-- End  bootstrap-touch-slider Slider -->

        </section>
        <?php endif; ?>
        

        
        <section class="wrapper">
            <div class="divider_border" style="background: url('<?php echo e(URL::asset('asset/img/divider.png')); ?>') center top no-repeat;"></div>  
            <div class="container">
                <?php if($pagesettings[0]->featuredpro_status): ?>
                <div class="main_title">
                    <h2>Welcome To Our <span><?php echo e($language->featured_products); ?></span></h2>
                    <p>Quisque at tortor a libero posuere laoreet vitae sed arcu. Curabitur consequat.</p>
                </div>
                
                <div class="row">
                    <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 col-sm-6 wow fadeIn animated" data-wow-delay="0.2s">
                        <div class="img_wrapper" >
                            <div class="ribbon">
                                <span>FEATURED</span>
                            </div>
                            <div class="price_grid">
                                <?php if($product->previous_price != ""): ?>
                                <span class="original-price"><?php echo e($settings[0]->currency_sign); ?><?php echo e($product->price); ?> <br>
                                <del class="offer-price"><?php echo e($settings[0]->currency_sign); ?><?php echo e($product->previous_price); ?></del>
                                <?php else: ?>
                                <span class="original-price"><?php echo e($settings[0]->currency_sign); ?><?php echo e($product->price); ?>

                                <?php endif; ?>
                            </div>
                            

                            <div class="img_container" style="min-height: 250px">
                                <a href="<?php echo e(url('/product')); ?>/<?php echo e($product->id); ?>/<?php echo e(str_replace(' ','-',strtolower($product->title))); ?>">
                                    <img src="<?php echo e(url('/assets/images/products/medium')); ?>/<?php echo e($product->feature_image); ?>" width="800" height="533" class="img-responsive" alt="">
                                    <div class="short_info">
                                        <h3><?php echo e($product->title); ?></h3>
                                        <em>Duration 45 mins</em>
                                        <p>
                                            <?php echo e(str_limit($product->description, $limit = 100, $end = '...')); ?>

                                           
                                        </p>
    
                                        <div class="ratings">
                                            <div class="empty-stars"></div>
                                            <div class="full-stars" style="width:<?php echo e(\App\Review::ratings($product->id)); ?>%"></div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <!-- End img_wrapper -->
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
                
                <!-- End row -->
    
                <p class="text-center add_bottom_45">
                    <a href="grid.html" class="product-filter-loadMore-btn">Explore all tours (24)</a>
                </p>
            </div>
        </section>
        

        
        <section class="wrapper">
            <div class="divider_border" style="background: url('<?php echo e(URL::asset('asset/img/divider.png')); ?>') center top no-repeat;"></div>
            <?php if($pagesettings[0]->category_status): ?>
            <div class="section-padding featured-categories padding-top-0 wow fadeInUp" >
                <div class="container">
        
                    <div class="product-featured-full-div padding-top-0">
                        <div class="row margin-bottom-0">
                            <div class="col-md-12">
                                <div class="main_title">
                                    <h2>View Our <span><?php echo e($language->top_category); ?></span></h2>
                                    <p>Quisque at tortor a libero posuere laoreet vitae sed arcu. Curabitur consequat.</p>
                                </div>
                            </div>
                        </div>
                        <div class="row featured-list">
                            <div class="featured-categories-wrapper">
                                <div class="col-md-6 col-sm-12">
                                    <div class="single-featured-area">
                                        <a href="<?php echo e(url('/category')); ?>/<?php echo e($fcategory->slug); ?>">
                                            <img class="featured-img" src="<?php echo e(url('/assets')); ?>/images/categories/small/<?php echo e($fcategory->feature_image); ?>" alt="">
                                            <div class="product-feature-content">
                                                <h3><?php echo e($fcategory->name); ?></h3>
                                                <?php if(\App\Product::where('status','1')->whereRaw('FIND_IN_SET(?,category)', [$fcategory->id])->count()>1): ?>
                                                    <p><?php echo e(\App\Product::where('status','1')->whereRaw('FIND_IN_SET(?,category)', [$fcategory->id])->count()); ?> places</p>
                                                <?php else: ?>
                                                    <p><?php echo e(\App\Product::where('status','1')->whereRaw('FIND_IN_SET(?,category)', [$fcategory->id])->count()); ?> place</p>
                                                <?php endif; ?>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <?php $__currentLoopData = $fcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-3 col-sm-6">
                                    <div class="single-featured-area">
                                        <a href="<?php echo e(url('/category')); ?>/<?php echo e($fcat->slug); ?>">
                                            <img class="featured-img" src="<?php echo e(url('/assets')); ?>/images/categories/small/<?php echo e($fcat->feature_image); ?>" alt="">
                                            <div class="product-feature-content">
                                                <h3><?php echo e($fcat->name); ?></h3>
                                                <?php if(\App\Product::where('status','1')->whereRaw('FIND_IN_SET(?,category)', [$fcat->id])->count()>1): ?>
                                                    <p><?php echo e(\App\Product::where('status','1')->whereRaw('FIND_IN_SET(?,category)', [$fcat->id])->count()); ?> places</p>
                                                <?php else: ?>
                                                    <p><?php echo e(\App\Product::where('status','1')->whereRaw('FIND_IN_SET(?,category)', [$fcat->id])->count()); ?> place</p>
                                                <?php endif; ?>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>
                    </div>
        
                </div>
            </div>
            <?php endif; ?>
            <?php if($pagesettings[0]->sbanner_status): ?>
            <!-- Starting of product-imageBlog area -->
            <div class="section-padding product-imageBlog-section padding-top-0 padding-bottom-0 wow fadeInUp">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="product-imgBlog-fullDiv">
                                <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-4">
                                    <a href="<?php echo e($banner->link); ?>" target="_blank">
                                        <img src="<?php echo e(url('/assets')); ?>/images/brands/<?php echo e($banner->image); ?>" alt="">
                                    </a>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <!-- Ending of product-imageBlog area -->
        </section>
        
        
        <section class="wrapper">
            <div class="divider_border" style="background: url('<?php echo e(URL::asset('asset/img/divider.png')); ?>') center top no-repeat;"></div>
            <div class="container">
               <?php if($pagesettings[0]->latestpro_status): ?>
                <div class="main_title">
                    <h2>Our TOP <span><?php echo e($language->latest_products); ?></span></h2>
                    <p>Quisque at tortor a libero posuere laoreet vitae sed arcu. Curabitur consequat.</p>
                </div>
                <div class="row">
        
                    <?php $__currentLoopData = $latests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 col-sm-6 wow fadeIn animated" data-wow-delay="0.2s">
        
                        <div class="img_wrapper">
                            <div class="ribbon">
                                <span>LEATEST</span>
                            </div>
                            <div class="price_grid">
                                <?php if($product->previous_price != ""): ?>
                                <span class="original-price"><?php echo e($settings[0]->currency_sign); ?><?php echo e($product->price); ?> <br>
                                <del class="offer-price"><?php echo e($settings[0]->currency_sign); ?><?php echo e($product->previous_price); ?></del>
                                <?php else: ?>
                                <span class="original-price"><?php echo e($settings[0]->currency_sign); ?><?php echo e($product->price); ?>

                                <?php endif; ?>
                            </div>
                            <div class="img_container">
                                <a href="<?php echo e(url('/product')); ?>/<?php echo e($product->id); ?>/<?php echo e(str_replace(' ','-',strtolower($product->title))); ?>">
                                    <img src="<?php echo e(url('/assets/images/products/medium')); ?>/<?php echo e($product->feature_image); ?>" width="800" height="533" class="img-responsive" alt="">
                                    <div class="short_info">
                                        <h3><?php echo e($product->title); ?></h3>
                                            <em>Duration 45 mins</em>
                                            <p>
                                                <?php echo e(str_limit($product->description, $limit = 100, $end = '...')); ?>

                                               
                                            </p>
                                        <div class="ratings">
                                            <div class="empty-stars"></div>
                                            <div class="full-stars" style="width:<?php echo e(\App\Review::ratings($product->id)); ?>%"></div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <!-- End img_wrapper -->
                        <div class="product-meta-area" >
                            <form class="addtocart-form">
                                <?php echo e(csrf_field()); ?>

                                <?php if(Session::has('uniqueid')): ?>
                                    <input type="hidden" name="uniqueid" value="<?php echo e(Session::get('uniqueid')); ?>">
                                <?php else: ?>
                                    <input type="hidden" name="uniqueid" value="<?php echo e(str_random(7)); ?>">
                                <?php endif; ?>
                                <input type="hidden" name="title" value="<?php echo e($product->title); ?>">
                                <input type="hidden" name="product" value="<?php echo e($product->id); ?>">
                                <input type="hidden" id="cost" name="cost" value="<?php echo e(\App\Product::Cost($product->id)); ?>">
                                <input type="hidden" id="quantity" name="quantity" value="1">
                                <?php if($product->stock != 0 || $product->stock === null ): ?>
                                    <button type="button" class="addTo-cart to-cart"><i class="fa fa-cart-plus"></i><span><?php echo e($language->add_to_cart); ?></span></button>
                                <?php else: ?>
                                    <button type="button" class="addTo-cart  to-cart" disabled><i class="fa fa-cart-plus"></i><?php echo e($language->out_of_stock); ?></button>
                                <?php endif; ?>
                            </form>
                            <a  href="javascript:;" class="wish-list" onclick="getQuickView(<?php echo e($product->id); ?>)" data-toggle="modal" data-target="#myModal">
                                <i class="fa fa-eye"></i>
                            </a>
                         </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </div>
                <?php endif; ?>
            </div>
        </section>        
        
        <!-- End section -->    
        <?php if($pagesettings[0]->lbanner_status): ?>
        <!-- Starting of Breadcroumb area -->
        <div class="breadcroumb-section text-center  wow fadeInUp">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <a href="<?php echo e($pagesettings[0]->banner_link); ?>" target="_blank">
                            <img style="width: 100%;" src="<?php echo e(url('/assets/images')); ?>/<?php echo e($pagesettings[0]->large_banner); ?>" alt="">
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <!-- Ending of Breadcroumb area -->
        <?php endif; ?>

        <!-- starting of best seller area -->
        <section class="wrapper">
            <div class="divider_border" style="background: url('<?php echo e(URL::asset('asset/img/divider.png')); ?>') center top no-repeat;"></div>
            <div class="container">
                <?php if($pagesettings[0]->popularpro_status): ?>
                <div class="main_title">
                    <h2>Our TOP <span><?php echo e($language->popular_products); ?></span></h2>
                    <p>Quisque at tortor a libero posuere laoreet vitae sed arcu. Curabitur consequat.</p>
                </div>
                <div class="row">
    
                    <?php $__currentLoopData = $tops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 col-sm-6 wow fadeIn animated" data-wow-delay="0.2s">
    
                        <div class="img_wrapper">
                            <div class="ribbon">
                                <span>Popular</span>
                            </div>
                            <div class="price_grid">
                                <?php if($product->previous_price != ""): ?>
                                <span class="original-price"><?php echo e($settings[0]->currency_sign); ?><?php echo e($product->price); ?> <br>
                                <del class="offer-price"><?php echo e($settings[0]->currency_sign); ?><?php echo e($product->previous_price); ?></del>
                                <?php else: ?>
                                <span class="original-price"><?php echo e($settings[0]->currency_sign); ?><?php echo e($product->price); ?>

                                <?php endif; ?>
                            </div>
                            <div class="img_container">
                                <a href="<?php echo e(url('/product')); ?>/<?php echo e($product->id); ?>/<?php echo e(str_replace(' ','-',strtolower($product->title))); ?>">
                                    <img src="<?php echo e(url('/assets/images/products/medium')); ?>/<?php echo e($product->feature_image); ?>" width="800" height="533" class="img-responsive" alt="">
                                    <div class="short_info">
                                        <h3><?php echo e($product->title); ?></h3>
                                            <em>Duration 45 mins</em>
                                            <p>
                                                <?php echo e(str_limit($product->description, $limit = 100, $end = '...')); ?>

                                               
                                            </p>
                                        <div class="ratings">
                                            <div class="empty-stars"></div>
                                            <div class="full-stars" style="width:<?php echo e(\App\Review::ratings($product->id)); ?>%"></div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <!-- End img_wrapper -->
                        <div class="product-meta-area" >
                            <form class="addtocart-form">
                                <?php echo e(csrf_field()); ?>

                                <?php if(Session::has('uniqueid')): ?>
                                    <input type="hidden" name="uniqueid" value="<?php echo e(Session::get('uniqueid')); ?>">
                                <?php else: ?>
                                    <input type="hidden" name="uniqueid" value="<?php echo e(str_random(7)); ?>">
                                <?php endif; ?>
                                <input type="hidden" name="title" value="<?php echo e($product->title); ?>">
                                <input type="hidden" name="product" value="<?php echo e($product->id); ?>">
                                <input type="hidden" id="cost" name="cost" value="<?php echo e(\App\Product::Cost($product->id)); ?>">
                                <input type="hidden" id="quantity" name="quantity" value="1">
                                <?php if($product->stock != 0 || $product->stock === null ): ?>
                                    <button type="button" class="addTo-cart to-cart"><i class="fa fa-cart-plus"></i><span><?php echo e($language->add_to_cart); ?></span></button>
                                <?php else: ?>
                                    <button type="button" class="addTo-cart  to-cart" disabled><i class="fa fa-cart-plus"></i><?php echo e($language->out_of_stock); ?></button>
                                <?php endif; ?>
                            </form>
                                <a  href="javascript:;" class="wish-list" onclick="getQuickView(<?php echo e($product->id); ?>)" data-toggle="modal" data-target="#myModal">
                                    <i class="fa fa-eye"></i>
                                </a>
                        </div>
                    
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
                </div>
                <?php endif; ?>
            </div>
        </section>
        <!-- Ending of best seller area -->
        <?php if($pagesettings[0]->subscribe_status): ?>
        <!-- Starting of product subscribe form area -->
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="product-subscribe-section text-center wow fadeInUp">
                        <img src="<?php echo e(url('/assets/images')); ?>/<?php echo e($settings[0]->background); ?>" alt="">
                        <div class="product-subscribe-form">
                            <div class="row">
                                <div class="col-lg-6 col-lg-offset-3 col-md-8 col-md-offset-2 col-sm-8 col-sm-offset-2  col-xs-10 col-xs-offset-1">
                                    <div class="product-subscribe-form-content">
                                        <div class="product-subscribe-icon">
                                            <i class="fa fa-envelope-o"></i>
                                        </div>
                                        <h1><?php echo e($language->subscription); ?></h1>
                                        
                                        <p id="resp"></p>
                                        <form id="subform" action="<?php echo e(action('FrontEndController@subscribe')); ?>" method="post">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="email" id="email" placeholder="Enter Email" name="email" required>

                                            <input id="subs"  type="button" class="btn subscribe-btn" value="<?php echo e($language->subscribe); ?>">
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Ending of product subscribe form area -->
        <?php endif; ?>


        <?php if($pagesettings[0]->blogs_status): ?>
        <!-- Starting of blog area -->
        <div class="section-padding blog-area-wrapper padding-bottom-0 wow fadeInUp">
            <div class="container">
                <div class="blog-area-fullDiv">
                    <div class="row">
                        <div class="col-md-6 col-md-offset-3">
                            <div class="section-title text-center">
                                <h2><?php echo e($languages->blog_title); ?></h2>
                                <p><?php echo e($languages->blog_text); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="blog-area-slider">
                                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="single-blog-box">
                                    <div class="blog-thumb-wrapper">
                                        <img src="<?php echo e(url('/assets')); ?>/images/blog/<?php echo e($blog->featured_image); ?>" alt="Blog Image">
                                    </div>
                                    <div class="blog-text">
                                        <p class="blog-meta"><?php echo e(date('d M Y',strtotime($blog->created_at))); ?></p>
                                        <h4><?php echo e($blog->title); ?></h4>
                                        <p><?php echo e(substr(strip_tags($blog->details),0,125)); ?></p>
                                        <a href="<?php echo e(url('/blog')); ?>/<?php echo e($blog->id); ?>" class="blog-more-btn"><?php echo e($language->view_details); ?></a>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Ending of blog area -->
        <?php endif; ?>
        <?php if($pagesettings[0]->testimonial_status): ?>
        <!-- Starting of customer review carousel area -->
        <div class="customer-review-carousel-wrapper text-center wow fadeInUp">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="customer-review-carousel-image">
                            <img src="<?php echo e(url('/assets/images')); ?>/<?php echo e($settings[0]->background); ?>" alt="">

                            <div class="review-carousel-table">
                                <div class="review-carousel-table-cell">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3 col-xs-12">
                                                <div class="section-title text-center">
                                                    <h2><?php echo e($languages->testimonial_title); ?></h2>
                                                    <p><?php echo e($languages->testimonial_text); ?></p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-sm-8 col-sm-offset-2">
                                                <div class="testimonial-section animated fadeInRight">
                                                    <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div>
                                                        <div class="box_overlay">
                                                            <div class="pic">
                                                                <figure><img src="<?php echo e(URL::asset('assets/images/cusavatar.png')); ?>" alt="" class="img-circle">
                                                                </figure>
                                                                <h4><?php echo e($testimonial->client); ?><small><?php echo e($testimonial->designation); ?></small></h4>
                                                            </div>
                                                            <div class="comment">
                                                                "<?php echo e($testimonial->review); ?>."
                                                            </div>
                                                        </div>
                                                        <!-- End box_overlay -->
                                                    </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Ending of customer review carousel area -->
        <?php endif; ?>
        <?php if($pagesettings[0]->brands_status): ?>
        <!-- Starting of brandLogo-carousel-wrapper area -->
        <div class="section-padding logo-carousel-wrapper  wow fadeInUp">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="logo-carousel">
                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="single-logo-item">
                                <div class="logo-item-inner">
                                    <img src="<?php echo e(url('/assets/images/brands')); ?>/<?php echo e($brand->image); ?>" alt="">
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Ending of brandLogo-carousel-wrapper area -->
        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script>

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.newmaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>